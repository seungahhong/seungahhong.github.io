// action type
export const INCREASE = 'FETCH_INCREASE';
export const DECREASE = 'FETCH_DECREASE';
export const SET_DIFF = 'FETCH_SET_DIFF';