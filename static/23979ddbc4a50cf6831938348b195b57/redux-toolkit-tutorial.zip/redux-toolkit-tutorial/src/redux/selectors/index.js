import { createSelector } from 'reselect';

const getNumber = (state) => state.number;
const getDiff = (state) => state.diff;
 

export const getIncreaseNumber = createSelector(
  getNumber,
  getDiff,
  (number, diff) => number + diff,
);

export const getDecreaseNumber = createSelector(
  getNumber,
  getDiff,
  (number, diff) => number - diff,
);
