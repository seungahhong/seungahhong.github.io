import { createActions } from 'redux-actions';
import { INCREASE, DECREASE, SET_DIFF } from '../constants';

// export const fetchIncrease = () => ({
//   type: INCREASE
// });

// export const fetchDecrease = () => ({
//   type: DECREASE
// });

// export const fetchSetDiff = diff => ({
//   dispatch({
//     type: SET_DIFF,
//     diff
//   });
// });

export const { 
  fetchIncrease, 
  fetchDecrease,
  fetchSetDiff,
} = createActions({
  [INCREASE]: () => {},
  [DECREASE]: () => {},
  [SET_DIFF]: (diff) => ({ diff }),
});

export const fetchAsyncSetDiff = (diff) => (dispatch, getState) =>  {
  const setAsyncDiff = async (diff) => {
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    dispatch(fetchSetDiff(diff));
  }

  try { 
    setAsyncDiff(diff);
  } catch(e) {
    throw new Error(e);
  }
};
