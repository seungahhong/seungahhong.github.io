import { combineReducers } from "redux";
import reducers from "../reducers";

console.log(reducers);
const rootReducers = () => combineReducers({
  counter: reducers.counter
});

export default rootReducers;