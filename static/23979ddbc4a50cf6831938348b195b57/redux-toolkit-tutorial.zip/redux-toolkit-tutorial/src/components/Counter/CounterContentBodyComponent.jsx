import React from "react";

const CounterContentBodyComponent = ({ diff }) => {
  
  return (
    <h1>{diff}</h1>
  );
}

export default React.memo(CounterContentBodyComponent, (prev, curr) => prev.diff === curr.diff);