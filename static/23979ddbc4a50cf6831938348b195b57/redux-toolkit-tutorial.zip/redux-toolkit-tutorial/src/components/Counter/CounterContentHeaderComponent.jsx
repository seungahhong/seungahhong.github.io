import React from "react";

const CounterContentHeaderComponent = ({ number }) => {
  
  return (
    <h1>{number}</h1>
  );
}

export default React.memo(CounterContentHeaderComponent, (prev, curr) => prev.number === curr.number);