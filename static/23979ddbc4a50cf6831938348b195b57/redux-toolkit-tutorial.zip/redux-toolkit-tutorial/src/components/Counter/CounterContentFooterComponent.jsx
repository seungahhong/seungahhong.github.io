import React from "react";

const CounterContentFooterComponent = ({ diff, onIncrease, onDecrease, onSetDiff }) => {
  
  const onChange = e => {
    onSetDiff(parseInt(e.target.value));
  };

  return (
    <div>
      <input type="number" value={diff} onChange={onChange}></input>
      <button onClick={onIncrease}>+</button>
      <button onClick={onDecrease}>-</button>
    </div>
  );
}

export default CounterContentFooterComponent;