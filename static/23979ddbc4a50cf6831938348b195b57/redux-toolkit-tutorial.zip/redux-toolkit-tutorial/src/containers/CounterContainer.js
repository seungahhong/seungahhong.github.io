import React from "react";
import { useSelector, useDispatch, shallowEqual } from "react-redux";
import CounterContentHeaderComponent from "../components/Counter/CounterContentHeaderComponent";
import CounterContentBodyComponent from "../components/Counter/CounterContentBodyComponent";
import CounterContentFooterComponent from "../components/Counter/CounterContentFooterComponent";
import { fetchIncrease, fetchDecrease, fetchAsyncSetDiff } from "../redux/actions";
// import { fetchIncrease, fetchDecrease, fetchAsyncSetDiff } from "../reduxtoolkit/features";

const CounterContainer = () => {
  const { number, diff } = useSelector(
    state => ({
      number: state.counter.number,
      diff: state.counter.diff
    }),
    shallowEqual
  );

  const dispatch = useDispatch();

  const onIncrease = () => dispatch(fetchIncrease());
  const onDecrease = () => dispatch(fetchDecrease());
  const onSetDiff = diff => dispatch(fetchAsyncSetDiff(diff));

  return (
    <>
      <CounterContentHeaderComponent
        number={number}
      />
      <CounterContentBodyComponent
        diff={diff}
      />
      <CounterContentFooterComponent
        diff={diff}
        onIncrease={onIncrease}
        onDecrease={onDecrease}
        onSetDiff={onSetDiff}
      />
    </>
  );
}

export default CounterContainer;