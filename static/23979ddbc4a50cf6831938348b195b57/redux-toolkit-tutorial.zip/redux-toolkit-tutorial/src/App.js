
import { Provider } from 'react-redux';
import CounterContainer from './containers/CounterContainer';
import configureStore from './redux/store';
const store = configureStore();

// import store from "./reduxtoolkit/store";

function App() {
  return (
    <Provider store={store}>
      <CounterContainer />
    </Provider>
  );
}

export default App;
