import { configureStore, getDefaultMiddleware } from '@reduxjs/toolkit';
import logger from 'redux-logger';

import reducers from "../features";

export default configureStore({
  reducer: {
    counter: reducers
  },
  middleware: getDefaultMiddleware().concat(logger),
});
