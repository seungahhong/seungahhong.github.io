// action type
export const INCREASE = 'FETCH_INCREASE';
export const DECREASE = 'FETCH_DECREASE';
export const SET_DIFF = 'FETCH_SET_DIFF';
export const FETCH_ASYNC_SET_DIFF = 'FETCH_ASYNC_SET_DIFF';