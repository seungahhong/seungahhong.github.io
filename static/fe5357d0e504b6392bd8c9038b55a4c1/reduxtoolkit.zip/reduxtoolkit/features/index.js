// ducks pattern 구조
import {
  createSlice, // handleActions 대체
  createSelector, // reselect 대체
  createAction, // createActions 대체
  createAsyncThunk, // redux-thunk 수신 간소화
} from "@reduxjs/toolkit";
import { INCREASE, DECREASE, SET_DIFF, FETCH_ASYNC_SET_DIFF } from '../constants';

// selector
const getNumber = (state) => state.number;
const getDiff = (state) => state.diff;
 
export const getIncreaseNumber = createSelector(
  getNumber,
  getDiff,
  (number, diff) => number + diff,
);

export const getDecreaseNumber = createSelector(
  getNumber,
  getDiff,
  (number, diff) => number - diff,
);

// createActions이 없어서 createAction으로 대체 
export const fetchIncrease = createAction(INCREASE);
export const fetchDecrease = createAction(DECREASE);
export const fetchSetDiff = createAction(SET_DIFF, function prepare(diff) { return { payload: { diff } } });

export const fetchAsyncSetDiff = createAsyncThunk(FETCH_ASYNC_SET_DIFF, async (diff, thunkAPI) => {
  await new Promise((resolve) => setTimeout(resolve, 1000));

  const { dispatch } = thunkAPI;
  dispatch(fetchSetDiff(diff));
});

// reducer, immer 내장
const initialState = {
  number: 0,
  diff: 1
};

// redux-actions handleActions 내장
const counter = createSlice({
  name: 'counter',
  initialState,
  reducers: { }, // key값으로 정의한 이름으로 자동으로 액션함수 생성
  extraReducers: { // 사용자가 정의한 이름의 액션함수가 생성
    [INCREASE]: (state) => {
      state.number = getIncreaseNumber(state);
    },
    [DECREASE]: (state) => {
      state.number = getDecreaseNumber(state);
    },
    [SET_DIFF]: (state, action) => {
      state.diff = action.payload.diff;
    },
    [fetchAsyncSetDiff.fulfilled]: (target, action) => {
     // 성공
    },
    [fetchAsyncSetDiff.pending]: (target, action) => {
      // 로딩
     },
     [fetchAsyncSetDiff.rejected]: (target, action) => {
      // 실패
     },
  },
});

export default counter.reducer;
