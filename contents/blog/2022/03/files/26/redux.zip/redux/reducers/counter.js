import { handleActions } from 'redux-actions';
import produce from 'immer';

import { INCREASE, DECREASE, SET_DIFF } from '../constants';
import { getIncreaseNumber, getDecreaseNumber } from '../selectors';

const initialState = {
  number: 0,
  diff: 1
};

export default handleActions({
  [INCREASE]: (state) => produce(state, draft => {
    draft.number = getIncreaseNumber(state);
  }),
  [DECREASE]: (state) => produce(state, draft => {
    draft.number = getDecreaseNumber(state);
  }),
  [SET_DIFF]: (state, action) => produce(state, draft => {
    draft.diff = action.payload.diff;
  }),
}, initialState);

// const initialState = {
//   number: 0,
//   diff: 1
// };

// export default function counter(state = initialState, action) {
//   switch (action.type) {
//     case INCREASE:
      // return produce(state, draft => {
      //   draft.number = getIncreaseNumber(state);
      // });
//     case DECREASE:
//       return produce(state, draft => {
//         draft.number = getDecreaseNumber(state);
//       });  
//     case SET_DIFF:
//       return produce(state, draft => {
//         draft.diff = action.payload.diff;
//       });  
//     default:
//       return state;
//   }
// }



