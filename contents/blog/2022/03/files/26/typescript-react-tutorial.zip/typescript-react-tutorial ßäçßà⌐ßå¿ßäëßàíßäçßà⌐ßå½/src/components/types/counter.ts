export interface ICounterNumProps {
  number: number;
};

export interface ICounterDiffProps {
  diff: number;
};

export interface ICounterProps extends ICounterDiffProps {
  onIncrease: () => void;
  onDecrease: () => void;
  onSetDiff: (diff: number) => void;
};