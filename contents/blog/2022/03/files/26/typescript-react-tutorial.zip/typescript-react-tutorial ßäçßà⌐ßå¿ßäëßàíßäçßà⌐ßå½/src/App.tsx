import React from 'react';
import { Provider } from 'react-redux';

import CounterContainter from './containers/CounterContainter';
// import configureStore from './redux/store';
// const store = configureStore();

import store from "./reduxtoolkit/store";

function App() {
  return (
    <Provider store={store}>
      <CounterContainter />
    </Provider>
  );
}

export default App;
