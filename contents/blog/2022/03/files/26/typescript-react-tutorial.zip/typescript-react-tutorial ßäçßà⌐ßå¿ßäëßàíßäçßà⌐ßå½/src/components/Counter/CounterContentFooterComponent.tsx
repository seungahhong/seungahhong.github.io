import React from "react";

import { ICounterProps } from '../types/counter';

const CounterContentFooterComponent = ({ 
  diff, 
  onIncrease, 
  onDecrease, 
  onSetDiff 
}: ICounterProps) => {
  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onSetDiff(parseInt(e.target.value));
  };

  return (
    <div>
      <input type="number" value={diff} onChange={onChange}></input>
      <button onClick={onIncrease}>+</button>
      <button onClick={onDecrease}>-</button>
    </div>
  );
};

export default CounterContentFooterComponent;