import { combineReducers } from "redux";
import reducers from "../reducers";

const rootReducers = () => combineReducers({
  'counter': reducers.counter
});

export default rootReducers;
