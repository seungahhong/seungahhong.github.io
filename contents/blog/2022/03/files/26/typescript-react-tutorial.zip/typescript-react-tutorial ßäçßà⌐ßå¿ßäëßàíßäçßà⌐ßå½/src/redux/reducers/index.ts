import counter from './counter'

export default {
  counter,
};