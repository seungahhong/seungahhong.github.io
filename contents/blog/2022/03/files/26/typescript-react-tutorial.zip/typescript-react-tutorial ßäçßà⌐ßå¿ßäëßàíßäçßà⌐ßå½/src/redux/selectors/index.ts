import { Selector } from 'react-redux';
import { createSelector } from 'reselect';

import { ICounterState } from '../types';

const getNumber = (state: ICounterState) => state.number;
const getDiff = (state: ICounterState) => state.diff;

export const getIncreaseNumber: Selector<ICounterState, number> = createSelector(
  getNumber,
  getDiff,
  (number, diff) => number + diff,
);

export const getDecreaseNumber: Selector<ICounterState, number> = createSelector(
  getNumber,
  getDiff,
  (number, diff) => number - diff,
);
