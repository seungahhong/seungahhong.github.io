// action type
export const INCREASE = 'FETCH_INCREASE' as const;
export const DECREASE = 'FETCH_DECREASE' as const;
export const SET_DIFF = 'FETCH_SET_DIFF' as const;

export const FETCH_ASYNC_SET_DIFF = 'FETCH_ASYNC_SET_DIFF' as const;
export const FETCH_ASYNC_SET_DIFF_SUCCESS = 'FETCH_ASYNC_SET_DIFF_SUCCESS' as const;
export const FETCH_ASYNC_SET_DIFF_FAIL = 'FETCH_ASYNC_SET_DIFF_FAIL' as const;