import React from "react";

import { ICounterDiffProps } from '../types/counter';

const CounterContentBodyComponent = ({ diff }: ICounterDiffProps) => {
  return (
    <h1>{diff}</h1>
  );
};

export default React.memo(CounterContentBodyComponent, (prev, curr) => prev.diff === curr.diff);