import { createAction } from 'typesafe-actions';
import { INCREASE, DECREASE, SET_DIFF, FETCH_ASYNC_SET_DIFF, FETCH_ASYNC_SET_DIFF_SUCCESS, FETCH_ASYNC_SET_DIFF_FAIL } from '../constants';
import { TypedThunk, TypedCounterAsync } from '../types';

export const fetchIncrease = createAction(INCREASE)();
export const fetchDecrease = createAction(DECREASE)();
export const fetchSetDiff = createAction(SET_DIFF, (diff: number) => ({ diff }))();

export const fetchAsyncSetDiffRequest = createAction(FETCH_ASYNC_SET_DIFF)();
export const fetchAsyncSetDiffRequestSuccess = createAction(FETCH_ASYNC_SET_DIFF_SUCCESS)();
export const fetchAsyncSetDiffRequestFail = createAction(FETCH_ASYNC_SET_DIFF_FAIL)<Error>();

export const fetchAsyncSetDiff = (diff: number): TypedThunk => async (dispatch) =>  {
  const { request, success, failure } = TypedCounterAsync;
  dispatch(request());

  try { 
    await new Promise((resolve) => setTimeout(resolve, 1000));
    
    dispatch(fetchSetDiff(diff));
    dispatch(success());
  } catch(e) {
    dispatch(failure(e));
  }
};
