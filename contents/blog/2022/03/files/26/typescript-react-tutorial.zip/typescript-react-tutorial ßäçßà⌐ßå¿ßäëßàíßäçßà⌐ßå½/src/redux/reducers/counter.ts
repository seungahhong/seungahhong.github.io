import { createReducer } from 'typesafe-actions';
import produce from 'immer';

import { SET_DIFF, INCREASE, DECREASE, FETCH_ASYNC_SET_DIFF, FETCH_ASYNC_SET_DIFF_SUCCESS, FETCH_ASYNC_SET_DIFF_FAIL } from '../constants';
import { getIncreaseNumber, getDecreaseNumber } from '../selectors';
import { ICounterState, CounterAction } from '../types';

const initialState: ICounterState = {
  number: 0,
  diff: 1,
  loading: false,
  message: '',
};

export default createReducer<ICounterState, CounterAction>(initialState, {
  [INCREASE]: (state) => produce(state, draft => {
    draft.number = getIncreaseNumber(state);
  }),
  [DECREASE]: (state) => produce(state, draft => {
    draft.number = getDecreaseNumber(state);
  }),
  [SET_DIFF]: (state, action) => produce(state, draft => {
    draft.diff = action.payload.diff;
  }),
  [FETCH_ASYNC_SET_DIFF]: (state) => {
    return {
      ...state,
      loading: true,
      message: '',
    };
  },
  [FETCH_ASYNC_SET_DIFF_SUCCESS]: (state, action) => {
    // 성공
    return {
      ...state,
      loading: false,
      message: '성공했습니다....'
    };
  },
  [FETCH_ASYNC_SET_DIFF_FAIL]: (state, action) => {
    // 실패
    return {
      ...state,
      loading: false,
      message: '실패했습니다...'
    };
  },
});

