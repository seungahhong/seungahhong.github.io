import React from "react";
import { useSelector, useDispatch, shallowEqual } from "react-redux";
import ReactLoading from "react-loading";

import CounterContentHeaderComponent from "../components/Counter/CounterContentHeaderComponent";
import CounterContentBodyComponent from "../components/Counter/CounterContentBodyComponent";
import CounterContentFooterComponent from "../components/Counter/CounterContentFooterComponent";
// import { ICounterState, RootState, RootDispatch, TypedThunkDispath } from '../redux/types';
// import { fetchIncrease, fetchDecrease, fetchAsyncSetDiff } from "../redux/actions";

import { ICounterState, RootState, RootDispatch, TypedThunkDispath } from '../reduxtoolkit/types';
import { fetchIncrease, fetchDecrease, fetchAsyncSetDiff } from "../reduxtoolkit/features";

const CounterContainer = () => {
  // ??
  const { number, diff, loading, message }: ICounterState = useSelector(
    ( state: RootState ) => ({
      number: state.counter.number,
      diff: state.counter.diff,
      loading: state.counter.loading,
      message: state.counter.message,
    }),
    shallowEqual
  );

  const dispatch = useDispatch<RootDispatch>();

  const onIncrease = () => dispatch(fetchIncrease());
  const onDecrease = () => dispatch(fetchDecrease());
  const onSetDiff = (diff: number) => (dispatch as TypedThunkDispath)(fetchAsyncSetDiff(diff));

  return (
    <>
      { loading ? <ReactLoading color={'#00b2b2'} height={50} width={50} /> : <h1>{message}</h1> }
      <CounterContentHeaderComponent
        number={number}
      />
      <CounterContentBodyComponent
        diff={diff}
      />
      <CounterContentFooterComponent
        diff={diff}
        onIncrease={onIncrease}
        onDecrease={onDecrease}
        onSetDiff={onSetDiff}
      />
    </>
  );
};

export default CounterContainer;