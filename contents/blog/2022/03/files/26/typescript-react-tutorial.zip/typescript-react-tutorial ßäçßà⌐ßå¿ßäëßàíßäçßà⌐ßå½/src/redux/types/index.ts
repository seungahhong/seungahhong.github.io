import { createAsyncAction } from 'typesafe-actions';
import { ThunkAction, ThunkDispatch } from 'redux-thunk';
import { fetchIncrease, fetchDecrease, fetchSetDiff, fetchAsyncSetDiffRequest, fetchAsyncSetDiffRequestSuccess, fetchAsyncSetDiffRequestFail } from "../actions";
import { RootState, RootDispatch } from '../store';
import { FETCH_ASYNC_SET_DIFF, FETCH_ASYNC_SET_DIFF_SUCCESS, FETCH_ASYNC_SET_DIFF_FAIL } from '../constants';

// reducers
export interface ICounterState {
  number: number;
  diff: number;
  loading: boolean;
  message: string;
}

// actions
export const TypedCounterAsync = createAsyncAction(
  FETCH_ASYNC_SET_DIFF,
  FETCH_ASYNC_SET_DIFF_SUCCESS,
  FETCH_ASYNC_SET_DIFF_FAIL,
)<undefined, undefined, Error>();

export type CounterAction =
  | ReturnType<typeof fetchIncrease>
  | ReturnType<typeof fetchDecrease>
  | ReturnType<typeof fetchSetDiff>
  | ReturnType<typeof fetchAsyncSetDiffRequest>
  | ReturnType<typeof fetchAsyncSetDiffRequestSuccess>
  | ReturnType<typeof fetchAsyncSetDiffRequestFail>;


export type TypedThunk = ThunkAction<void, ICounterState, unknown, CounterAction>;
export type TypedThunkDispath = ThunkDispatch<ICounterState, unknown, CounterAction>;

// reducers
export type RootState = ReturnType<typeof RootState>;
export type RootDispatch = typeof RootDispatch;