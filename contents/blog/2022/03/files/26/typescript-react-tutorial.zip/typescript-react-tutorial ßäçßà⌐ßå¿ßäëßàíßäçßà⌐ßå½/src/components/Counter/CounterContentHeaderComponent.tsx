import React from "react";
import { ICounterNumProps } from '../types/counter';

const CounterContentHeaderComponent = ({ number }: ICounterNumProps) => {
  return (
    <h1>{number}</h1>
  );
};

export default React.memo<ICounterNumProps>(CounterContentHeaderComponent, (prev, curr) => prev.number === curr.number);